// Hello World program
// by Emmanuel Almonte for CISC 111

package com.example.helloworld;
//Main class which has the output for the phrase "HelloWorld"
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }


}
