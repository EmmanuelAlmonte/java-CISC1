/*
 * Finding the distance of two points that a user inputs and then the hypotenuse of a triangle
 * Created for CSCI 111
 * last modified November 26, 2020.
 * @ author A. Emmanuel
 */
package com.example.triangle;

import java.util.Scanner;

/*
 *
 * @author emma
 */


public class Triangle {
    /**
     * Main Method outputs the quadrant of two points and the distance as well.
     * @param args the command line arguments
     */
    public static void main(String[] args){
        Scanner User = new Scanner(System.in);// created a scanner to store input form user

        double point_x;// the variable to the x coordinate
        double point_y;// variable for the y coordinate
        int dist;// variable to store distance
        String q1 = "Quadrant 1";// String for quadrant 1
        String q2 = "Quadrant 2";// String for quadrant 2
        String q3 = "Quadrant 3";// String for quadrant 3
        String q4 = "Quadrant 4";// String for quadrant 4

        String quadrant = ""; // I felt like adding an extra variable to store the actual quadrant after the code decides what quadrant the points are and store it in this variable

        System.out.println("Enter the x value: ");// Asking user to input a value for x
        point_x = User.nextDouble();// storing user data in point_x

        System.out.println("Enter a value for y: ");// Asking user to input a value for y
        point_y = User.nextDouble();// storing user data in point_y

        dist = (int) Math.hypot(point_x, point_y);// finding the distance

        // logic of the code to decide in which quadrant do the points land
        if (point_x > 0){
            if (point_y >0){
                quadrant = q1;
            }
        }
        else if (point_x <0){
            if(point_y>0){
                quadrant = q2;
            }
        }
        if (point_x <0){
            if(point_y<0){
                quadrant = q3;
            }
        }
        else if(point_x>0){
            if(point_y<0){
                quadrant = q4;
            }
        }// End of logic portion of code
        // output part of code which outputs distance and quadrant.
        System.out.println("The distance to the origin is "+ dist+ " and your point is in " + quadrant);









    }
}
