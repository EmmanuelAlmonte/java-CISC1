/*
 * Monthly Loan Calculator
 * Created for CISCI 111
 * last modified Nov 23, 2020
 * author A. Emmanuel
 */
package loancalculator;

import java.util.Scanner;
import static java.lang.Math.*;

public class LoanCalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int one_year = 12; // one year is equal to 12 months
        double month_rate; // Monthly Rate
        String home_address;  // The address of the property
        double loan;   // The amount of the loan
        double interest_rate;  // Annual Interest rate
        double num_of_pay; // Number of payments
        double monthly_pay; // cost of monthly payments
        Scanner User = new Scanner(System.in); // Scnaner to store user data
        System.out.println("What is the address on file for the loan? ");//User Input for address
        home_address = User.nextLine() ;// Store address for loan
        System.out.println("How much does the loan cost? ");// User Input for loan cost
        loan = User.nextDouble();//store loan cost
        System.out.println("What is the Annual rate of interest");// User Input for annual rate 
        interest_rate = User.nextDouble();//store annual rate
        System.out.println("How many years is the loan? "); // User Input for amount of years loan 
        num_of_pay = User.nextDouble();// store numbers of years
        num_of_pay = num_of_pay*one_year; //length in months of loan payments
        month_rate = interest_rate/one_year;// monthly interest rate
        monthly_pay = (month_rate*loan)/(1-Math.pow(1+month_rate, -num_of_pay));//calculate the effective monthly interest rate by dividing the annual rate
        System.out.println("The loan amount is: $" + loan); //Output loan amount
        System.out.println("The annual Interest Rate is: " + interest_rate);// Output Annual rate
        System.out.println("The number of monthly payments is: " + num_of_pay);//Output number of months
        System.out.println("The total cost per month is: " + monthly_pay);// Output amount of payment per month
    }
    
}
