/*
 * Temperature from Celsius to Fahrenheit 
 * Created for CSCI 111
 * last modified November 23, 2020.
 * @ author A. Emmanuel
 */
package tempconverter;

import java.util.*;
/*
 *
 * @author emma
 */



public class TempConverter {

    /**
     * Main Method converts Temperature from Celsius to Fahrenheit 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float celsius;//Float to store the celsius
        float faher;// The Float to store faherenheit
        int count = 0;// If needed a counter and can be used for print celsius but in int since they start at zero
        System.out.println("Celsius " + " Fahrenheit");
        celsius = 0;
        while(celsius <= 40)// While loop to create the conversion.
        {
            faher = (float) (( celsius * 1.8 ) +(32));
            System.out.println(count+ "    " + faher);
            celsius += 1;
            count++;

        }


    }
    
}
