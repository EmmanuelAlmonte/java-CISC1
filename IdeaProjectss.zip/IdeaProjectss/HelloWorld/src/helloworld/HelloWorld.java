/*
 * Hello World Application.
 * Created for CSCI 111
 * last modified November 16, 2020.
 * @ author A. Emmanuel
 */
package helloworld;


public class HelloWorld {

    /**
     * Main method outputs a message on screen
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }//end main()
    
}//end class HelloWorld
